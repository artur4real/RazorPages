# RazorPagesMovie

A simple Movies web application built with ASP.NET CORE using Razor Pages. 
